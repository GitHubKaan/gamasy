package gms.ui.desktop;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class frame implements WindowListener {
	
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	static gms.ui.desktop.content desktopContentClass = new gms.ui.desktop.content();
	
	static gms.ui.desktop.frame_position uiFramePosClass = new gms.ui.desktop.frame_position();
	
	JFrame frame = new JFrame(generalSettingsClass.msg_dsk_0());
	
	public frame() {
		generalPrinterClass.logPrintln(this.getClass() + " > utilization");
		
		
		
		frame.setSize(1200, 700);
		frame.setResizable(false);
		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(this);
		
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		
		
		if (uiFramePosClass.getFramePos() != null) {
			frame.setLocation(uiFramePosClass.getFramePos());
		} else {
			if (generalSettingsClass.getHostMode() == true) {
				frame.setLocation(-1500, 300);
			} else {
				frame.setLocationRelativeTo(null);
			}
		}
		
		
		URL icon_image_url = getClass().getResource("/gms/textures/general/gms_icon0.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		frame.add(desktopContentClass);
	}
	

	
	public boolean getFrameVisibility() {
		return frame.isVisible();
	}
	public void setFrameVisibility(boolean v) {
		frame.setVisible(v);
	}
	public Point getFrameLocation() {
		return frame.getLocation();
	}
	public void setFrameLocation(int i, int j) {
		if (i == 0 && j == 0) {
			frame.setLocationRelativeTo(null);
		} else {
			frame.setLocation(i, j);
		}
	}
	
	
	/*
	 * ALLES TRASH HIER UNTEN
	 */
	
	@Override
	public void windowOpened(WindowEvent e) {
	}

	@Override
	public void windowClosed(WindowEvent e) {
	}

	@Override
	public void windowIconified(WindowEvent e) {
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
	}

	@Override
	public void windowActivated(WindowEvent e) {
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		generalPrinterClass.logPrintln("display-window closed via x-button");
		
		//gms.ui.developer.statusGetter uiDeveloperStatusGetter = new gms.ui.developer.statusGetter();
		
		//uiDeveloperStatusGetter.setPanel13(Color.RED);
	}
	
	@Override
	public void windowClosing(WindowEvent e) {
	}
}
