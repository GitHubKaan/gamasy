package gms.ui.desktop;

import java.awt.Point;

public class frame_position {

	static gms.general.printer printerClass = new gms.general.printer();
	
	static Point pos;
	
	public frame_position() {
		printerClass.logPrintln(this.getClass() + " > utilization");
	}
	
	public void setFramePos(Point p) {
		pos = p;
		printerClass.logPrintln("frame position saved for desktop: " + pos);
	}

	public Point getFramePos() {
		return pos;
	}
}
