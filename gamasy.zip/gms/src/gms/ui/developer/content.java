package gms.ui.developer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FontFormatException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import gms.general.main;

public class content extends JPanel implements ActionListener {
	
	gms.general.printer generalPrinterClass = new gms.general.printer();
	gms.general.settings generalSettingsClass = new gms.general.settings();
	gms.ui.desktop.frame_position uiFramePositionClass = new gms.ui.desktop.frame_position();
	gms.ui.desktop.frame uiDesktopClass = new gms.ui.desktop.frame();
	gms.ui.developer.statusGetter uiDeveloperStatusGetter = new gms.ui.developer.statusGetter();
	gms.ui.mobile.contentGetter uiMobileGetterClass = new gms.ui.mobile.contentGetter();
	
	Color col0 = new Color(21, 21, 21);
	Color col1 = new Color(40, 40, 40);
	
	Color transp = new Color(0f, 0f, 0f, 0f);
	Color parttransp = new Color(0f, 0f, 0f, 0.3f);
	
	static JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100];
	JButton[] buttons = new JButton[100];
	
	public content() {
		
		
		
		gms.general.fonts generalFontsClass = null;
		try {
			generalFontsClass = new gms.general.fonts();
		} catch (FontFormatException | IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		setBackground(col0);
		setLayout(null);
		
		for (int i = 0; i < panels.length; i++) {
			panels[i] = new JPanel();
			panels[i].setVisible(false);
		}
		
		
		//[]==========[ oberer hellgrauer Balken ]==========[]
		panels[0].setVisible(true);
		panels[0].setBackground(col1);
		panels[0].setBounds(0, 0, 1280, 150);
		
		
		//[]==========[ unterer hellgrauer Bereich ]==========[]
		panels[1].setVisible(true);
		panels[1].setBackground(col1);
		panels[1].setBounds(500, 153, 765, 530);
		
		
		//[]==========[ verbindender Balken 1 vom oberen und unteren Bereich ]==========[]
		panels[2].setVisible(true);
		panels[2].setBackground(col1);
		panels[2].setBounds(500, 150, 395, 10);
			
		
		//[]==========[ verbindender Balken 2 vom oberen und unteren Bereich ]==========[]
		panels[3].setVisible(false);
		panels[3].setBackground(col1);
		panels[3].setBounds(895, 150, 395, 10);
		
		
		
		//[]==========[ linkes oberes bild ]==========[]
		panels[4].setVisible(true);
		panels[4].setBackground(transp);
		panels[4].setBounds(20, 20, 110, 110);
		
		labels[0] = new JLabel();
		labels[0].setVisible(true);
		
		URL image_url = main.class.getResource("/gms/textures/ui/developer/gms_developer_object0.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(100, 100, Image.SCALE_REPLICATE);
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		
		panels[4].add(labels[0]);
		
		
		//[]==========[ linker oberer text neben dem Programm Icon ]==========[]
		panels[5].setVisible(true);
		panels[5].setBackground(transp);
		panels[5].setBounds(131, 20, 368, 110);
		
		
		
		
		labels[1] = new JLabel(generalSettingsClass.msg_dev_0());
		labels[1].setFont(generalFontsClass.getFont0());
		labels[1].setBounds(5, 17, 400, 30);
		labels[1].setForeground(Color.WHITE);
		//labels[1].setOpaque(true);
		labels[1].setVisible(true);
		
		if (generalSettingsClass.getHostMode() == true) {
			labels[1].setForeground(Color.RED);
			labels[1].setText(generalSettingsClass.msg_dev_0() + " " + generalSettingsClass.msg_host_tag);
		}
		
		labels[2] = new JLabel(generalSettingsClass.msg_dev_1());
		labels[2].setFont(generalFontsClass.getFont1());
		labels[2].setBounds(7, 45, 400, 50);
		labels[2].setForeground(Color.WHITE);
		//labels[2].setOpaque(true);
		labels[2].setVisible(true);
		
		panels[5].setLayout(null);
		panels[5].add(labels[1]);
		panels[5].add(labels[2]);
		
		
		
		/*
		 * WICHTIG: HIER k�nnen die buttons drauf zum klicken der beideren oberen optionen
		 */
		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new JButton();
			labels[i] = new JLabel();
			
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
		}
		
		//[]==========[ Target Area 1 ]==========[]
		panels[90].setVisible(true);
		panels[90].setOpaque(false);
		panels[90].setBounds(500, 0, 395, 150);
		//[]==========[ button for info ]==========[]
		panels[90].setLayout(new BorderLayout(0, 0));
		panels[90].add(buttons[0]);
		
		//[]==========[ Target Area 2 ]==========[]
		panels[91].setVisible(true);
		panels[91].setOpaque(false);
		panels[91].setBounds(895, 0, 395, 150);
		//[]==========[ button for settings ]==========[]
		panels[91].setLayout(new BorderLayout(0, 0));
		panels[91].add(buttons[1]);
		
		

		
		
		//ICON
		//[]==========[ grauer Bereich in der mitte (info) - icon ]==========[]
		panels[6].setVisible(true);
		panels[6].setBackground(transp);
		panels[6].setBounds(550, 20, 50, 50);
		panels[6].setLayout(null);
		
		labels[3] = new JLabel();
		labels[3].setBounds(0, 0, 50, 50);
		
		URL image_url2 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object1.png");
		
		BufferedImage image2 = null;
		try { //Bild Import
			image2 = ImageIO.read(image_url2);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image scaled_image2 = image2.getScaledInstance(50, 50, Image.SCALE_REPLICATE);
		
		ImageIcon bgimage2 = new ImageIcon(scaled_image2);
		
		labels[3].setIcon(bgimage2);
		
		labels[3].setVisible(true);
		panels[6].add(labels[3]);
				
		//[]==========[ grauer Bereich rechts (settings/einstellungen) - icon ]==========[]
		panels[7].setVisible(true);
		panels[7].setBackground(transp);
		panels[7].setBounds(915, 20, 50, 50);
		panels[7].setLayout(null);
		
		labels[4] = new JLabel();
		labels[4].setBounds(0, 0, 50, 50);
		
		URL image_url3 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object2_negativ.png");
		
		BufferedImage image3 = null;
		try { //Bild Import
			image3 = ImageIO.read(image_url3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image scaled_image3 = image3.getScaledInstance(50, 50, Image.SCALE_REPLICATE);
		
		ImageIcon bgimage3 = new ImageIcon(scaled_image3);
		
		labels[4].setIcon(bgimage3);
		
		labels[4].setVisible(true);
		panels[7].add(labels[4]);
		
		
		
		
		
		
		//TEXT / JLabel (muss noch eingef�gt werden)
		//[]==========[ grauer Bereich in der mitte (info) - text ]==========[]
		panels[8].setVisible(true);
		panels[8].setBackground(transp);
		panels[8].setBounds(550, 75, 300, 50);
		panels[8].setLayout(null);
		
		labels[5] = new JLabel(generalSettingsClass.msg_dev_2(), SwingConstants.LEFT);
		labels[5].setForeground(Color.WHITE);
		labels[5].setFont(generalFontsClass.getFont1());
		labels[5].setBounds(0, 0, 300, 50);
		panels[8].add(labels[5]);
		
		//[]==========[ grauer Bereich rechts (settings/einstellungen) - text ]==========[]
		panels[9].setVisible(true);
		panels[9].setBackground(transp);
		panels[9].setBounds(915, 75, 300, 50);
		panels[9].setLayout(null);
		
		labels[6] = new JLabel(generalSettingsClass.msg_dev_3(), SwingConstants.LEFT);
		labels[6].setForeground(Color.GRAY);
		labels[6].setFont(generalFontsClass.getFont1());
		labels[6].setBounds(0, 0, 300, 50);
		panels[9].add(labels[6]);
		
		
		
		
		
		//[]==========[ positionierung box desktop view ]==========[]
		panels[10].setVisible(true);
		panels[10].setBackground(parttransp);
		panels[10].setBounds(30, 175, 440, 150);
		//[]==========[ positionierung box mobile view ]==========[]
		panels[11].setVisible(true);
		panels[11].setBackground(parttransp);
		panels[11].setBounds(30, 340, 440, 150);
		//[]==========[ positionierung box database view ]==========[]
		panels[12].setVisible(true);
		panels[12].setBackground(parttransp);
		panels[12].setBounds(30, 505, 440, 150);
		
		//[]==========[ positionierung box desktop view balken ]==========[]
		panels[13].setVisible(true);
		panels[13].setBackground(Color.DARK_GRAY);
		panels[13].setBounds(30, 175, 10, 150);
		//[]==========[ positionierung box mobile view balken ]==========[]
		panels[14].setVisible(true);
		panels[14].setBackground(Color.DARK_GRAY);
		panels[14].setBounds(30, 340, 10, 150);
		//[]==========[ positionierung box database view balken ]==========[]
		panels[15].setVisible(true);
		panels[15].setBackground(Color.DARK_GRAY);
		panels[15].setBounds(30, 505, 10, 150);
		
		
		
		
		
		
		
		//[]==========[ positionierung icon box desktop ]==========[]
		panels[16].setVisible(true);
		panels[16].setOpaque(false);
		panels[16].setBounds(60, 215, 70, 70);
		panels[16].setLayout(new BorderLayout(0, 0));
		
		URL image_url10 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object3.png");
		BufferedImage image10 = null;
		try { image10 = ImageIO.read(image_url10); } catch (IOException e) { e.printStackTrace(); }
		Image scaled_image10 = image10.getScaledInstance(70, 70, Image.SCALE_REPLICATE);
		ImageIcon bgimage10 = new ImageIcon(scaled_image10);
		
		labels[7].setIcon(bgimage10);
		panels[16].add(labels[7]);
		//[]==========[ positionierung icon box mobile ]==========[]
		panels[17].setVisible(true);
		panels[17].setOpaque(false);
		panels[17].setBounds(60, 380, 70, 70);
		panels[17].setLayout(new BorderLayout(0, 0));
		
		URL image_url11 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object4.png");
		BufferedImage image11 = null;
		try { image11 = ImageIO.read(image_url11); } catch (IOException e) { e.printStackTrace(); }
		Image scaled_image11 = image11.getScaledInstance(70, 70, Image.SCALE_REPLICATE);
		ImageIcon bgimage11 = new ImageIcon(scaled_image11);
		
		labels[8].setIcon(bgimage11);
		panels[17].add(labels[8]);
		//[]==========[ positionierung icon box database ]==========[]
		panels[18].setVisible(true);
		panels[18].setOpaque(false);
		panels[18].setBounds(60, 545, 70, 70);
		panels[18].setLayout(new BorderLayout(0, 0));
		
		URL image_url12 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object5.png");
		BufferedImage image12 = null;
		try { image12 = ImageIO.read(image_url12); } catch (IOException e) { e.printStackTrace(); }
		Image scaled_image12 = image12.getScaledInstance(70, 70, Image.SCALE_REPLICATE);
		ImageIcon bgimage12 = new ImageIcon(scaled_image12);
		
		labels[9].setIcon(bgimage12);
		panels[18].add(labels[9]);
		
		
		
		
		//[]==========[ positionierung desktop box text field ]==========[]
		panels[19].setVisible(true);
		panels[19].setBounds(160, 210, 290, 35);
		panels[19].setLayout(new BorderLayout(0, 0));
		panels[19].setOpaque(false);
		
		labels[10].setText(generalSettingsClass.msg_dev_5());
		labels[10].setForeground(Color.WHITE);
		labels[10].setFont(generalFontsClass.getFont1());
		panels[19].add(labels[10]);
		
		//[]==========[ positionierung mobile box text field ]==========[]
		panels[20].setVisible(true);
		panels[20].setBounds(160, 375, 290, 35);
		panels[20].setLayout(new BorderLayout(0, 0));
		panels[20].setOpaque(false);
		 
		labels[11].setText(generalSettingsClass.msg_dev_6());
		labels[11].setForeground(Color.WHITE);
		labels[11].setFont(generalFontsClass.getFont1());
		panels[20].add(labels[11]);
		
		//[]==========[ positionierung database box text field ]==========[]
		panels[21].setVisible(true);
		panels[21].setBounds(160, 540, 290, 35);
		panels[21].setLayout(new BorderLayout(0, 0));
		panels[21].setOpaque(false);
		
		labels[12].setText(generalSettingsClass.msg_dev_7());
		labels[12].setForeground(Color.WHITE);
		labels[12].setFont(generalFontsClass.getFont1());
		panels[21].add(labels[12]);
		
		
		
		
		
		//[]==========[ positionierung desktop box text field 2 ]==========[]
		panels[22].setVisible(true);
		panels[22].setBounds(160, 248, 290, 50);
		panels[22].setLayout(new BorderLayout(0, 0));
		panels[22].setOpaque(false);
		
		labels[13].setText(generalSettingsClass.msg_dev_8());
		labels[13].setForeground(Color.WHITE);
		labels[13].setFont(generalFontsClass.getFont1());
		panels[22].add(labels[13]);
		//[]==========[ positionierung mobile box text field 2 ]==========[]
		panels[23].setVisible(true);
		panels[23].setBounds(160, 413, 290, 50);
		panels[23].setLayout(new BorderLayout(0, 0));
		panels[23].setOpaque(false);
		
		labels[14].setText(generalSettingsClass.msg_dev_9());
		labels[14].setForeground(Color.WHITE);
		labels[14].setFont(generalFontsClass.getFont1());
		panels[23].add(labels[14]);
		//[]==========[ positionierung database box text field 2 ]==========[]
		panels[24].setVisible(true);
		panels[24].setBounds(160, 578, 290, 50);
		panels[24].setLayout(new BorderLayout(0, 0));
		panels[24].setOpaque(false);
		
		labels[15].setText(generalSettingsClass.msg_dev_10());
		labels[15].setForeground(Color.WHITE);
		labels[15].setFont(generalFontsClass.getFont1());
		panels[24].add(labels[15]);
		
		
		
		
		//[]==========[ linke Seite JButton 1 ]==========[]
		panels[25].setVisible(true);
		panels[25].setBounds(30, 175, 440, 150);
		panels[25].setOpaque(false);
		panels[25].setLayout(new BorderLayout(0, 0));
		
		buttons[2].setVisible(true);
		panels[25].add(buttons[2]);
		
		//[]==========[ linke Seite JButton 2 ]==========[]
		panels[26].setVisible(true);
		panels[26].setBounds(30, 340, 440, 150);
		panels[26].setOpaque(false);
		panels[26].setLayout(new BorderLayout(0, 0));
		
		buttons[2].setVisible(true);
		panels[26].add(buttons[3]);
		
		//[]==========[ linke Seite JButton 3 ]==========[]
		panels[27].setVisible(true);
		panels[27].setBounds(30, 505, 440, 150);
		panels[27].setOpaque(false);
		panels[27].setLayout(new BorderLayout(0, 0));
		
		buttons[4].setVisible(true);
		panels[27].add(buttons[4]);
		
		
		
		
		
		//[]==========[ info text field ]==========[]
		panels[28].setVisible(true);
		panels[28].setBounds(520, 177, 725, 170);
		//panels[28].setBackground(Color.RED);
		panels[28].setLayout(null);
		panels[28].setOpaque(false);
		
		labels[20].setFont(generalFontsClass.getFont1());
		labels[20].setBounds(30, 0, 725, 170);
		labels[20].setText(generalSettingsClass.msg_dev_11());
		labels[20].setForeground(Color.WHITE);
		panels[28].add(labels[20]);
		
		
		
		//[]==========[ info settings field ]==========[]
		panels[29].setVisible(false);
		panels[29].setBounds(520, 177, 725, 478);
		panels[29].setBackground(Color.BLUE);
		panels[29].setLayout(null);
		
		labels[21].setFont(generalFontsClass.getFont1());
		labels[21].setBounds(30, 0, 725, 478);
		labels[21].setText(generalSettingsClass.msg_dev_12());
		labels[21].setForeground(Color.WHITE);
		panels[29].add(labels[21]);
		
		
		
		//[]==========[ settings page ]==========[]
		buttons[10].setBounds(0, 0, 200, 100);
		panels[29].add(buttons[10]);
		
		buttons[10].setText("RESET");
				
		buttons[10].setOpaque(true);
		buttons[10].setContentAreaFilled(true);
		buttons[10].setBorderPainted(true);
		
		buttons[10].addActionListener(this);
		
		
		
		
		for (int i = 0; i < panels.length; i++) { //z�hlt von 99 runter damit die neureren (unteren) Ebenen ganz oben platziert werden
			add(panels[99 - i]);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		generalPrinterClass.logPrintln("actionevent at " + this.getClass() + " for " + e.getSource().toString());
		
		
		
		
		
		
		if (e.getSource().equals(buttons[0])) { //informations JPanel
			panels[2].setVisible(true);
			labels[5].setForeground(Color.WHITE);
			panels[3].setVisible(false);
			labels[6].setForeground(Color.GRAY);
			
			URL image_url3 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object2_negativ.png");
			BufferedImage image3 = null;
			try { //Bild Import
				image3 = ImageIO.read(image_url3);
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			
			Image scaled_image3 = image3.getScaledInstance(50, 50, Image.SCALE_REPLICATE);
			
			ImageIcon bgimage3 = new ImageIcon(scaled_image3);
			
			labels[4].setIcon(bgimage3);
			
			URL image_url2 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object1.png");
			
			BufferedImage image2 = null;
			try { //Bild Import
				image2 = ImageIO.read(image_url2);
			} catch (IOException e4) {
				e4.printStackTrace();
			}
			
			Image scaled_image2 = image2.getScaledInstance(50, 50, Image.SCALE_REPLICATE);
			
			ImageIcon bgimage2 = new ImageIcon(scaled_image2);
			
			panels[28].setVisible(true);
			panels[29].setVisible(false);
			
			labels[3].setIcon(bgimage2);
			
			generalPrinterClass.logPrintln("main developer frame tab switch to info");
		} else if (e.getSource().equals(buttons[1])) { //settings JPanel
			panels[2].setVisible(false);
			labels[5].setForeground(Color.GRAY);
			panels[3].setVisible(true);
			labels[6].setForeground(Color.WHITE);
			
			buttons[10].setVisible(true);
			
			URL image_url3 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object2.png");
			BufferedImage image3 = null;
			try { //Bild Import
				image3 = ImageIO.read(image_url3);
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			
			Image scaled_image3 = image3.getScaledInstance(50, 50, Image.SCALE_REPLICATE);
			
			ImageIcon bgimage3 = new ImageIcon(scaled_image3);
			
			labels[4].setIcon(bgimage3);
			
			
			URL image_url2 = main.class.getResource("/gms/textures/ui/developer/gms_developer_object1_negativ.png");
			
			BufferedImage image2 = null;
			try { //Bild Import
				image2 = ImageIO.read(image_url2);
			} catch (IOException e3) {
				e3.printStackTrace();
			}
			
			Image scaled_image2 = image2.getScaledInstance(50, 50, Image.SCALE_REPLICATE);
			
			ImageIcon bgimage2 = new ImageIcon(scaled_image2);
			
			labels[3].setIcon(bgimage2);
			
			panels[28].setVisible(false);
			panels[29].setVisible(true);
			
			generalPrinterClass.logPrintln("main developer frame tab switch to settings");
			
		} else if (e.getSource().equals(buttons[2])) {
			
			
			
			
			
			
			
			if (uiDesktopClass.getFrameVisibility() == false) {
				generalPrinterClass.logPrintln("desktop app start...");
				panels[13].setBackground(Color.GREEN);
				
				uiDesktopClass.setFrameVisibility(true);
			} else {
				generalPrinterClass.logPrintln("desktop app stopping...");
				panels[13].setBackground(Color.RED);
				
				uiFramePositionClass.setFramePos(uiDesktopClass.getFrameLocation());
				uiDesktopClass.setFrameVisibility(false);
			}
			
			
			
			
			
			
		} else if (e.getSource().equals(buttons[3])) {

			
			if (uiMobileGetterClass.getFrameVisibility() == true) {
				generalPrinterClass.logPrintln("mobile app closing...");
				
				uiMobileGetterClass.setFrameVisibility(false);
				
				uiMobileGetterClass.setFramePos(uiMobileGetterClass.getACTUALFramePosX(), uiMobileGetterClass.getACTUALFramePosY());
				
				panels[14].setBackground(Color.RED);
			} else {
				generalPrinterClass.logPrintln("mobile app start...");
				
				uiMobileGetterClass.setFrameVisibility(true);
				if (uiMobileGetterClass.getFramePosX() == 0 && uiMobileGetterClass.getFramePosY() == 0) {
					if (generalSettingsClass.getHostMode() == true) {
						uiMobileGetterClass.setFramePos(-800, 300);
					} else {
						uiMobileGetterClass.setFramePos(0, 0);
					}
				} else {
					uiMobileGetterClass.setFramePos(uiMobileGetterClass.getFramePosX(), uiMobileGetterClass.getFramePosY());
				}
				
				
				panels[14].setBackground(Color.GREEN);
			}
			
			
			
			
			
			
			
			
		} else if (e.getSource().equals(buttons[4])) {
			generalPrinterClass.logPrintln("database app start...");
			
			panels[15].setBackground(Color.GREEN);
		} else if (e.getSource().equals(buttons[5])) {
			
		} else if (e.getSource().equals(buttons[6])) {
			
			
			
			
			
			
			
			
			
		/*
		 * =====================================================================================
		 * 
		 * SETTINGS RESET BUTTON
		 * 
		 * =====================================================================================
		 */
		} else if (e.getSource() == buttons[10]) { //SETTINGS -> RESET button
			setVisible(false);
			
			buttons[0].doClick(); //auf die info seite switchen
			
			for (int i = 13; i < 16; i++) { //die buttons wieder auf grau stellen und nicht auf rot odewr gr�n
				panels[i].setBackground(Color.DARK_GRAY);
			}
			
			uiFramePositionClass.setFramePos(null);
			if (generalSettingsClass.getHostMode() == true) {
				uiDesktopClass.setFrameLocation(-1500, 300);
			} else {
				uiDesktopClass.setFrameLocation(0, 0);
			}
			
			uiDesktopClass.setFrameVisibility(false);
			
			
			uiMobileGetterClass.setFrameVisibility(false);
			uiMobileGetterClass.setReset(true);
			/*
			 * MUSS HIER ERG�NZ WERDEN WENN DIE NEUEN FENSTER HINZUGEF*GT WERDEN
			 */
			
			
			
			

			generalPrinterClass.logPrintln("software reset");
			setVisible(true);
			
			
			
			gms.ui.developer.frame.frame.setVisible(false);
			new gms.ui.intro.frame();
		} else {
			generalPrinterClass.logPrintErr("actionevent event without action-source");
		}
		
		

		
	}
}
