package gms.ui.intro;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import gms.general.main;

public class frame {
	
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	static gms.ui.developer.content developerContentClass = new gms.ui.developer.content();
	
	public frame() {
		generalPrinterClass.logPrintln(this.getClass() + " > utilization");
		
		JFrame frame = new JFrame(generalSettingsClass.msg_dev_4());
		
		int frame_size_x = generalSettingsClass.getIntroX();
		int frame_size_y = generalSettingsClass.getIntroY();
		
		frame.setSize(frame_size_x, frame_size_y);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setUndecorated(true);
		frame.setLayout(new BorderLayout(0, 0));
		
		JLabel background = new JLabel();
		background.setBounds(0, 0, 50, 50);
		
		URL image_url2 = main.class.getResource("/gms/textures/intro/gms_intro.png");
		
		BufferedImage image2 = null;
		try { //Bild Import
			image2 = ImageIO.read(image_url2);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image scaled_image2 = image2.getScaledInstance(frame_size_x, frame_size_y, Image.SCALE_REPLICATE);
		
		ImageIcon bgimage2 = new ImageIcon(scaled_image2);
		
		background.setIcon(bgimage2);
		
		background.setVisible(true);
		frame.add(background);
		
		URL icon_image_url = getClass().getResource("/gms/textures/general/gms_icon0.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		if (generalSettingsClass.getHostMode() == true) {
			frame.setLocation(-1200, 600);
		} else {
			frame.setLocationRelativeTo(null);
		}
		
		if (generalSettingsClass.getHostMode() == true || generalSettingsClass.getIntroStatus() == true) {
			
			new gms.ui.developer.frame();
		} else {
			try {
				frame.setVisible(true);
				
			    Thread.sleep(generalSettingsClass.getIntroTime());
			    
			    frame.setVisible(false);
			
				new gms.ui.developer.frame();
			}
			catch(InterruptedException e) {
			    Thread.currentThread().interrupt();
			}
		}
	}
}
