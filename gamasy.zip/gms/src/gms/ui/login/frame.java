package gms.ui.login;

import java.awt.Color;

import javax.swing.JFrame;

public class frame {
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	/*
	 * WIRD NICHT GENUTZT
	 */	/*
	 * WIRD NICHT GENUTZT
	 */	/*
	 * WIRD NICHT GENUTZT
	 */	/*
	 * WIRD NICHT GENUTZT
	 */	/*
	 * WIRD NICHT GENUTZT
	 */	/*
	 * WIRD NICHT GENUTZT
	 */	/*
	 * WIRD NICHT GENUTZT
	 */
	public frame() {
		generalPrinterClass.logPrintln(this.getClass() + " > utilization");
		
		JFrame frame = new JFrame("gms login view");
		
		frame.setSize(500, 500);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		
		if (generalSettingsClass.getHostMode() == true) {
			frame.setLocation(2200, 300);
		} else {
			frame.setLocationRelativeTo(null);
		}
		
		frame.setVisible(false);
	}
}
