package gms.ui.mobile;

import java.awt.Color;

import javax.swing.JPanel;

public class content extends JPanel {
	public content() {
		setBackground(Color.BLACK);
	}
}
