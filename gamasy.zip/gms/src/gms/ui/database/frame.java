package gms.ui.database;

import java.awt.Color;

import javax.swing.JFrame;

public class frame {
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	public frame() {
		generalPrinterClass.logPrintln(this.getClass() + " > utilization");
		
		JFrame frame = new JFrame("gms database view");
		
		frame.setSize(380, 720);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		
		if (generalSettingsClass.getHostMode() == true) {
			frame.setLocation(2625, 300);
		} else {
			frame.setLocationRelativeTo(null);
		}
		
		frame.setVisible(false);
	}
}
