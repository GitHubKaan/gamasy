package gms.general;

public class main {
	/*
	 *       @@@@@@@@@@@                 @@@@@@@@        @@@@@@@                 @@@@@@@@@@@@
   	 *	  @@@@@@@@@@@@@@@@@              @@@@@@@@@      @@@@@@@@               @@@@@@@@@@@@@@@@   
   	 *	  @@@@@       @@@@@              @@@@@@@@@     @@@@@@@@@               @@@@@      @@@@@@
   	 *	  @@@@@       @@@@@              @@@@@@@@@@   @@@@@@@@@@               @@@@@
   	 *	  @@@@@                          @@@@@@@@@@@  @@@@@@@@@@               @@@@@@@@@@@@@@
   	 *	  @@@@@    @@@@@@@@              @@@@@@ @@@@@@@@@@ @@@@@                @@@@@@@@@@@@@@@@
   	 *	  @@@@@    @@@@@@@@              @@@@@@ @@@@@@@@@  @@@@@                          @@@@@@
   	 *	  @@@@@       @@@@@              @@@@@@  @@@@@@@@  @@@@@               @@@@@      @@@@@@
   	 *	  @@@@@@@@@@@@@@@@@    @@@@@     @@@@@@   @@@@@@   @@@@@     @@@@@     @@@@@@@@@@@@@@@@@    @@@@@
     *		@@@@@@@@@@@@@      @@@@@     @@@@@@    @@@@    @@@@@     @@@@@       @@@@@@@@@@@@@      @@@@@
     *
     *	  [Ga]stronomy [Ma]nagement [Sy]stem
     *	  Developer: K�an Turan
     *	  Version: 0.0.1
	 */
	
	/* NOTIZEN:
	 * 		- Root Modus (Admin Modus) -> auch bei fenstertitel irg root reinschreiben
	 * 		- Ein Admin Fenster machen wo man bsp. Mobile starten kann und dann auch die normale desktop anwendung
	 * 		- Ein Datenbankfesnter erstellen
	 */
	
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingClass = new gms.general.settings();
	
	public static void main(String[] args) {
		generalPrinterClass.logPrintln("software starting... (version: 0.0.1)");
		
		System.out.println("Gamasy (G.M.S.) System | A system developed by LIGHT\n"
				 + "	|_ main: " + main.class + "\n"
				 + "	|_ version: " + generalSettingClass.getSoftVer() + "\n"
				 + "	|_ developer: k�an turan");
		
		
		//starten der Erstklassen ("weiter unten" ist am Ende "weiter oben")
		new gms.ui.intro.frame();
		/*
		new gms.ui.desktop.frame();
		new gms.ui.mobile.frame();
		new gms.ui.login.frame();
		new gms.ui.database.frame();
		new gms.ui.developer.frame();
		*/
		
	}
}
