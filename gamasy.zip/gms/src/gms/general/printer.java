package gms.general;

public class printer {
	public void logPrint(String l) {
		System.out.println("[ OK ] " + l);
	}
	
	public void logPrintln(String l) {
		System.out.println("[ OK ] " + l);
	}
	
	public void logPrintErr(String l) {
		System.err.println("[ ERR ] " + l);
	}
}
