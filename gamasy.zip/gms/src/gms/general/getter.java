package gms.general;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class getter {
	gms.general.printer generalPrinterClass = new gms.general.printer();
	
	public String getHostname() { //benutzernamen vom aktuellen benutzer bekommen
		String hostname = null;
		try {
		    InetAddress inetaddr;
		    inetaddr = InetAddress.getLocalHost();
		    hostname = inetaddr.getHostName();
		} catch (UnknownHostException e) {
		    generalPrinterClass.logPrintErr("desktop hostname unknown (exception: " + e + ")");
		}
		
		return hostname;
	}
}
