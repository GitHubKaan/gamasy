package gms.general;

public class printer {
	
	public void logPrint(String l) {
		System.out.println("[ OK ] " + l);
	}
	
	public void logPrintln(String l) {
		System.out.println("[ OK ] " + l);
	}
	
	public void logPrintErr(String l) {
		System.err.println("[ ERR ] " + l);
	}
	
	public void logEmulatorPrint(String l) {
		System.out.println("[ OK - EMU ] " + l);
	}
	
	public void logEmulatorErrPrint(String l) {
		System.err.println("[ ERR - EMU ] " + l);
	}
}
