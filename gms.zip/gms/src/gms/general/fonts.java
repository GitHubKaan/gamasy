package gms.general;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;

public class fonts {
	
	public fonts() throws FontFormatException, IOException {
		//Schriftarten einf�gen
		/*
		try {
		    //create the font to use. Specify the size!
		    Font customFont = Font.createFont(Font.TRUETYPE_FONT, new File("/gms/fonts/Roboto-Medium.ttf")).deriveFont(12f);
		    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		    //register the font
		    ge.registerFont(customFont);
		} catch (IOException e) {
		    e.printStackTrace();
		} catch(FontFormatException e) {
		 
		   e.printStackTrace();
		} */
	}
	
	public Font getFont0() {
		return new Font("Arial", Font.BOLD, 27);
	}
	public Font getFont1() {
		return new Font("Arial", Font.PLAIN, 15);
	}
	public Font getFont2() {
		return new Font("Arial", Font.PLAIN, 17);
	}
}
