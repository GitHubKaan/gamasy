package gms.general;

public class settings {
	
	gms.general.getter generalGetterClass = new gms.general.getter();
	
	
	//-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*
	
	/* enableHostMode: Host Modus (ist nicht der Root Modus)
	 * 		- individuelle JFrame Positionierung f�r den Entwickler Computer
	 */
	public boolean enableHostMode = true; //(true = an, false = aus)
	public boolean enableSecScreenMode = false; //Host-Mode -> fenster mid screen
	
	public int FramePosX = -1070; //host mode frame pos
	public int FramePosY = 100;
	
	public String msg_host_tag = "[root mode]";
	
	//-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*
	
	public boolean openTerminal = true; //Optimiert nur f�r Main Host Computer
	
	//-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*
	
	int introFrameSizeX = 480; //Intro JFrame gr��e
	int introFrameSizeY = 240;
	
	int introTime = 1000; //Wie lange das Intro sichtbar ist (1000 = 1 Sekunde)
	
	boolean disableIntro = false; //intro deaktivieren (true = deaktivieren)
	
	//-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*
	
	/*
	 * Frames beim start mit�ffnen, bitte nur eines auf true stellen
	 */
	
	public boolean preOpenDSK = true;
	public boolean preOpenMBL = false;
	public boolean preOpenDB = false;
	
	//-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*
	
	/* 
	 * Texte (ENGLISH)
	 */
	
	String softVer = "0.0.1"; //software version
	
	
	//DEVELOPER FRAME
	String msg_dev_0 = "Gamasy";
	String msg_dev_1 = "<html>Dev Mode - Inspection of all elements<br/>A system developed by LIGHT</html>";
	String msg_dev_2 = "<html><b>Info</b><br/>General software information</html>";
	String msg_dev_3 = "<html><b>Settings</b><br/>General software settings</html>";
	String msg_dev_4 = "Gamasy [" + softVer + "]";
	String msg_dev_5 = "<html><h1>Desktop application</h1></html>";
	String msg_dev_6 = "<html><h1>Mobile application</h1></html>";
	String msg_dev_7 = "<html><h1>Database application</h1></html>";
	String msg_dev_8 = "<html><p>this option serves to illustrate</p></br><p>the desktop application</p></html>";
	String msg_dev_9 = "<html><p>this option serves to illustrate</p></br><p>the mobile application</p></html>";
	String msg_dev_10 = "<html><p>this option serves to illustrate</p></br><p>the database structure</p></html>";
	String msg_dev_11 = "<html><p>general software information | gamasy</p><p></p></br></br><p>developer: k�an turan</p></br><p>optimized for java version: javase-15</p></br><p>software version: " + softVer + "</p></br><p>optimized default system to run on: windows 10</p></br><p>current pc id: " + generalGetterClass.getHostname() + "</p></br><p>host mode enabled: " + enableHostMode + "</p></html>";
	String msg_dev_12 = "<html><p>factory reset software</p></html>";
	public String msg_dev_13 = "<html><p>exit software</p></html>";
	public String msg_dev_14 = "<html><p>change mode (in maintenance)</p></html>";
	
	
	//DESKTOP FRAME
	public String msg_dsk_0 = "Gamasy - Desktop [" + softVer + "]";
	
	//MOBILE FRAME
	public String msg_mbl_0 = "Gamasy - Mobile [" + softVer + "]";
	
	//DATABASE FRAME
	public String msg_db_0 = "Gamasy - Database [" + softVer + "]";
	
	
	
	/* 
	 * Texte (GERMAN)
	 */
	
	
	
	
	
	
//===================================================================================================================================
	public int getIntroX() {
		return introFrameSizeX;
	}
	public int getIntroY() {
		return introFrameSizeY;
	}
	
	int temper = 0;
	public void setTemper(int i) {
		temper = i;
	}
	public int getTemper() {
		return temper;
	}
	
	public void setHostMode(boolean m) {
		enableHostMode = m;
	}
	
	public int getIntroTime() {
		return introTime;
	}
	
	public boolean getIntroStatus() {
		return disableIntro;
	}
	
	public String getSoftVer() {
		return softVer;
	}
	public String msg_dsk_0() {
		return msg_dsk_0;
	}
	public String msg_dev_0() {
		return msg_dev_0;
	}
	public String msg_dev_1() {
		return msg_dev_1;
	}
	public String msg_dev_2() {
		return msg_dev_2;
	}
	public String msg_dev_3() {
		return msg_dev_3;
	}
	public String msg_dev_4() {
		return msg_dev_4;
	}
	public String msg_dev_5() {
		return msg_dev_5;
	}
	public String msg_dev_6() {
		return msg_dev_6;
	}
	public String msg_dev_7() {
		return msg_dev_7;
	}
	public String msg_dev_8() {
		return msg_dev_8;
	}
	public String msg_dev_9() {
		return msg_dev_9;
	}
	public String msg_dev_10() {
		return msg_dev_10;
	}
	public String msg_dev_11() {
		return msg_dev_11;
	}
	public String msg_dev_12() {
		return msg_dev_12;
	}
	public boolean getHostMode() {
		return enableHostMode;
	}
	public boolean getSecScreenMode() {
		if (enableHostMode == false) {
			enableSecScreenMode = false;
		}
		return enableSecScreenMode;
	}	
	public String msg_host_tag() {
		return msg_host_tag;
	}
	public boolean getTerminalStatus() {
		return openTerminal;
	}
}
