package gms.ui.terminal.notinuse;

import java.awt.Color;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class termiview {
	
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	
	public JLabel[] txtline = new JLabel[100];
	public JFrame frame = new JFrame("terminal");
	public int lineHeight = 20;
	public int totalLineSpace = 20; //frame Height / lineHeight
	
	public termiview() {
		
		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setBounds(-1900, 180, 700, 400);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setLayout(null);
		frame.setResizable(false);
		
		URL icon_image_url = getClass().getResource("/gms/textures/general/terminal_icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		if (generalSettingsClass.getTerminalStatus() == false) {
			frame.setVisible(false);
		} else {
			frame.setVisible(true);
			
			generalPrinterClass.logPrintln("terminal starting now...");
		}
		
		
		for (int i = 0; i < txtline.length; i++) {
			txtline[i] = new JLabel("loading...");
			txtline[i].setVisible(true);
			txtline[i].setForeground(Color.WHITE);
			frame.add(txtline[i]);
		}
		
		for (int i = 0; i < totalLineSpace; i++) {
			txtline[i].setBounds(0, i*lineHeight, frame.getWidth(), lineHeight);
		}
	}
	
	
	
	
	
	
	
	
	
}
