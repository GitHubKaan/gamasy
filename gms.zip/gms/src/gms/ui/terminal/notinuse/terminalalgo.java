package gms.ui.terminal.notinuse;

public class terminalalgo {

	public static void setText(String string) {
		// TODO Auto-generated method stub
		
	}

	/*
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * MUSS GEMACHT WERDEN
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 	static gms.ui.terminal.termiview info = new gms.ui.terminal.termiview();
	static String importText = "test";
	
	public terminalalgo() {
		
	}

	public static void setText(String s) {
		importText = s;
		
		System.out.println(info.frame.isVisible());
		

		 //AUS IRG EINEM GRUND L�sst SICH NICHTS AUS TERMINAL VIEW ABLESEN; KEIN PLAN WARUM... SELBST WENN MAN KL�ASSENNAMEN ABFRAGT


		System.out.println("kaka");
		info.txtline[info.totalLineSpace].setText(importText);
			
			
		for (int i = 0; i < info.totalLineSpace; i++) {
			info.txtline[i].setText(info.txtline[i+1].getText());
		}
			
		info.frame.repaint();	

	}
	 */
}
