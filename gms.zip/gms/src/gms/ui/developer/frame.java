package gms.ui.developer;

import java.awt.Color;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.UIManager;

public class frame {
	
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	static gms.ui.developer.content developerContentClass = new gms.ui.developer.content();
	
	static JFrame frame = new JFrame(generalSettingsClass.msg_dev_4());
	
	public frame() {
		generalPrinterClass.logPrintln(this.getClass() + " > utilization");
		
		if (generalSettingsClass.getHostMode() == true) {
			frame.setTitle(generalSettingsClass.msg_dev_4() + " " + generalSettingsClass.msg_host_tag);
		}
		
		frame.setSize(1280, 720);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		
		frame.add(developerContentClass);
		
		//frame.setUndecorated(true);
		
		URL icon_image_url = getClass().getResource("/gms/textures/general/gms_icon1.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		if (generalSettingsClass.getHostMode() == true && generalSettingsClass.getSecScreenMode() == false) {
			frame.setLocation(generalSettingsClass.FramePosX, generalSettingsClass.FramePosY);
		} else {
			frame.setLocationRelativeTo(null);
		}
		
		frame.setVisible(true);
	}
}
