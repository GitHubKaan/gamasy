package gms.ui.developer;

import java.awt.Color;

public class statusGetter {
	
	/*
	 * KEINEN NUTZEN WURDE RAUSGEWIORFEN
	 */
	
	static Color Panel13Col;
	
	public void setPanel13(Color c) {
		Panel13Col = c;
	}
	public Color getPanel13() {
		return Panel13Col;
	}
}
