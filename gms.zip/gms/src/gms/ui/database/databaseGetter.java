package gms.ui.database;

public class databaseGetter {
	static gms.general.printer printerClass = new gms.general.printer();
	static gms.ui.database.frame uiMobileFrameClass = new gms.ui.database.frame();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	static int locx;
	static int locy;
	static boolean rst;
	
	public databaseGetter() {
		printerClass.logPrintln(this.getClass() + " > utilization");
	}
	
	public void setFramePos(int i, int j) {
		locx = i;
		locy = j;
		printerClass.logPrintln("frame position saved for mobile: " + locx + ", " + locy);
		
		if ((locx == 0 && locy == 0) || rst == true) {
			if (generalSettingsClass.getHostMode() == true && generalSettingsClass.getSecScreenMode() == false) {
				uiMobileFrameClass.frame.setLocation(5000, 300);
			} else {
				uiMobileFrameClass.frame.setLocationRelativeTo(null);
			}
			
			rst = false;
		} else {
			uiMobileFrameClass.frame.setLocation(locx, locy);
		}
	}

	public int getFramePosX() {
		return locx;
	}
	public int getFramePosY() {
		return locy;
	}
	
	public int getACTUALFramePosX() {
		return uiMobileFrameClass.frame.getX();
	}
	public int getACTUALFramePosY() {
		return uiMobileFrameClass.frame.getY();
	}
	
	public boolean getFrameVisibility() {
		return uiMobileFrameClass.frame.isVisible();
	}
	
	public void setFrameVisibility(boolean v) {
		uiMobileFrameClass.frame.setVisible(v);
	}
	
	public void setReset(boolean r) {
		rst = r;
	}
}
