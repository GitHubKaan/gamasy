package gms.ui.mobile;

import java.awt.Color;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class frame {
	static gms.general.printer generalPrinterClass = new gms.general.printer();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	static gms.ui.mobile.content uiMobileContentClass = new gms.ui.mobile.content();
	static gms.ui.mobile.contentGetter getterClass = new gms.ui.mobile.contentGetter();
	
	JFrame frame = new JFrame(generalSettingsClass.msg_mbl_0);
	
	public frame() {
		generalPrinterClass.logPrintln(this.getClass() + " > utilization");
		
		if (generalSettingsClass.getHostMode() == true) {
			frame.setTitle(generalSettingsClass.msg_mbl_0 + " " + generalSettingsClass.msg_host_tag);
		}
		
		frame.setSize(380, 720);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.add(uiMobileContentClass);
		
		if (generalSettingsClass.preOpenMBL == true && generalSettingsClass.getHostMode() == true) {
			frame.setVisible(true);
		}
		
		URL icon_image_url = getClass().getResource("/gms/textures/general/gms_icon0.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
	}
}

