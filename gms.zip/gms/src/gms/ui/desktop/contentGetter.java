package gms.ui.desktop;

public class contentGetter {
	static gms.general.printer printerClass = new gms.general.printer();
	static gms.ui.desktop.frame uiDesktopFrameClass = new gms.ui.desktop.frame();
	static gms.general.settings generalSettingsClass = new gms.general.settings();
	
	static int locx;
	static int locy;
	static boolean rst;
	
	public contentGetter() {
		printerClass.logPrintln(this.getClass() + " > utilization");
	}
	
	public void setFramePos(int i, int j) {
		locx = i;
		locy = j;
		printerClass.logPrintln("frame position saved for mobile: " + locx + ", " + locy);
		
		if ((locx == 0 && locy == 0) || rst == true) {
			if (generalSettingsClass.getHostMode() == true && generalSettingsClass.getSecScreenMode() == false) {
				uiDesktopFrameClass.frame.setLocation(0, 300);
			} else {
				uiDesktopFrameClass.frame.setLocationRelativeTo(null);
			}
			
			rst = false;
		} else {
			uiDesktopFrameClass.frame.setLocation(locx, locy);
		}
	}

	public int getFramePosX() {
		return locx;
	}
	public int getFramePosY() {
		return locy;
	}
	
	public int getACTUALFramePosX() {
		return uiDesktopFrameClass.frame.getX();
	}
	public int getACTUALFramePosY() {
		return uiDesktopFrameClass.frame.getY();
	}
	
	public boolean getFrameVisibility() {
		return uiDesktopFrameClass.frame.isVisible();
	}
	
	public void setFrameVisibility(boolean v) {
		uiDesktopFrameClass.frame.setVisible(v);
	}
	
	public void setReset(boolean r) {
		rst = r;
	}
}
