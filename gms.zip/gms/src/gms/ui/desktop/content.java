package gms.ui.desktop;

import java.awt.Color;

import javax.swing.JPanel;

import gms.general.printer;

public class content extends JPanel {
	
	static gms.general.settings settingsClass = new gms.general.settings();
	static gms.general.printer printerClass = new gms.general.printer();
	
	public content() {
		printerClass.logEmulatorPrint("Desktop load...");
		
		if (settingsClass.getHostMode() == true) { //hintergrundsfarbe
			setBackground(Color.CYAN);
		} else {
			setBackground(Color.BLACK);
		}
		
		
	}
}
