module gms {
	requires java.desktop;
}